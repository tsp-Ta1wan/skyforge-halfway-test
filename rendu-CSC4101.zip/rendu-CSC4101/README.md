### Bonjour! Ici tu trouveras tous les données nécéssaires pour l'évaluation de mon projet Skyforge.

## Informations générales
**Etudiant**: Louay Belkhamsa

**Nom du projet**: Skyforge

**Thème**: Site pour la création de collections de pièces militaires (épées, arcs, armures, pistolets, etc...)

## Nomenclature:
Inventaire = arsenal 

Objet = piece

## Avancement:
Toutes les étapes du checklist sont normalement réalisée.
Vous pouvez consulter ce lien pour le [TODO.md](https://github.com/tsp-Ta1wan/Skyforge/blob/dev/TODO.md)


## Erreurs/fonctionnalités manquantes:
Tous les fonctionnalités codées se compilent et marchent correctement sur mon environnement. 
